
public class B {
    public static void main(String[] args) {
        A ob1=new A();
        //except private all are accessible within the package
        // System.out.println(ob1.x);
        // System.out.println(ob1.y);
        // System.out.println(ob1.z);
        // System.out.println(ob1.w);
    }
}
