
public class C extends A {
    public static void main(String[] args) {
        A ob2=new A();
        //default and private are not accessible outside packge
        //System.out.println(ob2.x);
       // System.out.println(ob2.y);
        // System.out.println(ob2.z);
        // System.out.println(ob2.w);
    }
}
